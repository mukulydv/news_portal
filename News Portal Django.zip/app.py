from flask import Flask, render_template, send_from_directory

app = Flask(__name__)
@app.route("/")
def home_page():
    return render_template('index.html')
    
@app.route('/style')
def send_css():
    return send_from_directory('style','style.css')

@app.route('/script.js')
def send_js():
    return send_from_directory('static', 'script.js')

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug = True)   