// Fetch the JSON data
// fetch('/tester.json')
// .then(response => response.json())
// .then(data => {
//     // Get the article titles and display them in HTML
//     const articleList = document.getElementById('article-list');
//     data.articles.forEach(article => {
//         const listItem = document.createElement('li');
//         listItem.textContent = article[0].title;
//         `<p>Mukul</p>`
//         articleList.appendChild(listItem);
//     });
// })
// .catch(error => console.error(error));



let p = fetch("https://gnews.io/api/v4/search?q=example&apikey=c86e2b5aae7bff8fb261c50dbe3e946f")
p.then((value1)=>{
    return value1.json
}).then((value2)=>{
    let placeholder  = document.querySelector("api-news");
    let out = "";
    for (const value of value2) {
        out +=`
            <tr>
                <td> <img src='${value.image}' </td>
            </tr>
        `
    }
    placeholder.innerHTML = out;
})




















// async function logJSONData() {
//     const response = await fetch("https://gnews.io/api/v4/search?q=example&apikey=c86e2b5aae7bff8fb261c50dbe3e946f");
//     const jsonData = await response.json();
//     console.log(jsonData.articles[0].title);
    // return jsonData
    // console.log('hello', jsonData.articles[0].title)
    // console.log('hello', jsonData.articles[0].description)
    // for(let i = 0; i < 9; i++){
    // document.querySelectorAll("#api-news").innerHTML = [jsonData.articles[i].content,jsonData.articles[i].description];}
    // querySelectorAll("#api-news").innerHTML = [jsonData.articles[2].content,jsonData.articles[2].description];
    // document.querySelector("#api-news").innerHTML = [jsonData.articles[0].description];
    
//   }
  
//   const data = logJSONData()

//   fetch("https://gnews.io/api/v4/search?q=example&apikey=c86e2b5aae7bff8fb261c50dbe3e946f")
//   .then(response => response.json())
//   .then(data => {
//     // Access properties of the first object
//     console.log(data[0].name);
//     console.log(data[0].age);

//     // Access properties of the second object
//     console.log(data[1]['title']);
//     console.log(data[1]['content']);
//   })
//   .catch(error => console.error(error));