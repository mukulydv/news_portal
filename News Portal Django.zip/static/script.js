async function logJSONData() {
  // const response = await fetch("https://gnews.io/api/v4/search?q=example&apikey=c86e2b5aae7bff8fb261c50dbe3e946f");
  const response = await fetch("http://127.0.0.1:5500/static/tester.json");
  const jsonData = await response.json();
  console.log(jsonData);
  // return jsonData
  console.log('hello', jsonData.articles)

  let placeholder = document.getElementById('api-news')
  let out = "";
  for (let product of jsonData.articles) {
  console.log(product)
  out += `

  <div class="row">
  <div class="col-md-4">
    <img class="api-image col-md-3" src="${product.image}" alt="Image">
    </div>
    <div class="col-md-8">
    <h2 class="api-title" style="margin-bottom: 15px;">${product.title}</h2>


    <h3 class="api-content">${product.content}</h3>
    <a href="${product.url}" target="_blank"><p> Click to explore more</p></a>

    
    </div>
  </div>
  
  
  `
  }
  placeholder.innerHTML = out;
}
  


const data = logJSONData()
{/* <h3 class="api-publishedAt  ">${product.publishedAt}</h3> */}

// add this below produt.title for description

{/* <p>Description:<h3 class="api-decsription">${product.description}</h3><p> */}